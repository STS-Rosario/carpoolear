export const dummyGetter = (state) => {
    return 'Hello world!';
};
