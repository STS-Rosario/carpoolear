export default {
    inserted: function (el) {
        el.focus();
    }
};
